class Estudiante:
    def __init__(self, id, nombre, email, carnet, materias=None, notas=None):
        self.id = id
        self.nombre = nombre
        self.email = email
        self.carnet = carnet
        self.materias = materias or []
        self.notas = notas or {}

    def to_dict(self):
        return {
            "id": self.id, "nombre": self.nombre, "email": self.email,
            "carnet": self.carnet, "materias": self.materias,
            "notas": self.notas
        }

    @staticmethod
    def from_dict(d):
        return Estudiante(d["id"], d["nombre"], d["email"], d["carnet"],
                           d.get("materias", []), d.get("notas", {}))
