import json
from pathlib import Path
from models import Estudiante

RUTA = Path("data/estudiantes.json")

class EstudianteController:
    def __init__(self):
        self.estudiantes = []
        self.cargar_datos()

    def cargar_datos(self):
        if RUTA.exists():
            try:
                datos = json.loads(RUTA.read_text(encoding="utf-8"))
                self.estudiantes = [Estudiante.from_dict(x) for x in datos]
            except json.JSONDecodeError:
                self.estudiantes = []

    def guardar_datos(self):
        RUTA.parent.mkdir(exist_ok=True)
        RUTA.write_text(
            json.dumps([e.to_dict() for e in self.estudiantes],
                       ensure_ascii=False, indent=4),
            encoding="utf-8"
        )

    def obtener_por_id(self, id):
        return next((e for e in self.estudiantes if e.id == id), None)

    # CRUD
    def crear_estudiante(self, nombre, email, carnet, materias=None):
        if any(e.email.lower() == email.lower() for e in self.estudiantes):
            return False, "El email ya está registrado."
        if any(e.carnet == carnet for e in self.estudiantes):
            return False, "El carnet ya está registrado."

        nuevo_id = max((e.id for e in self.estudiantes), default=0) + 1
        self.estudiantes.append(
            Estudiante(nuevo_id, nombre, email, carnet, materias or [], {})
        )
        self.guardar_datos()
        return True, f"Estudiante creado. ID: {nuevo_id}"

    def obtener_todos(self):
        return self.estudiantes

    def buscar_estudiantes(self, texto):
        texto = texto.lower()
        return [e for e in self.estudiantes
                if texto in e.nombre.lower()
                or texto in e.email.lower()
                or texto in e.carnet.lower()]

    def actualizar_estudiante(self, id, nombre=None, email=None,
                              carnet=None, materias=None):
        e = self.obtener_por_id(id)
        if e is None:
            return False, "Estudiante no encontrado."

        if email and any(x.id != id and x.email.lower() == email.lower()
                         for x in self.estudiantes):
            return False, "El email ya está registrado."
        if carnet and any(x.id != id and x.carnet == carnet
                          for x in self.estudiantes):
            return False, "El carnet ya está registrado."

        if nombre: e.nombre = nombre
        if email: e.email = email
        if carnet: e.carnet = carnet
        if materias is not None: e.materias = materias
        self.guardar_datos()
        return True, "Estudiante actualizado."

    def eliminar_estudiante(self, id):
        e = self.obtener_por_id(id)
        if e is None:
            return False, "Estudiante no encontrado."
        self.estudiantes.remove(e)
        self.guardar_datos()
        return True, "Estudiante eliminado."

    def agregar_nota(self, id, materia, nota):
        e = self.obtener_por_id(id)
        if e is None:
            return False, "Estudiante no encontrado."
        try:
            nota = float(nota)
        except ValueError:
            return False, "La nota debe ser numérica."
        if not 0 <= nota <= 20:
            return False, "La nota debe estar entre 0 y 20."

        if materia not in e.materias:
            e.materias.append(materia)
        e.notas[materia] = nota
        self.guardar_datos()
        return True, "Nota agregada correctamente."

    def promedio_estudiante(self, id):
        e = self.obtener_por_id(id)
        if e is None or not e.notas:
            return None
        return sum(e.notas.values()) / len(e.notas)

    def materias_ofertadas(self):
        materias = set()
        for e in self.estudiantes:
            materias.update(e.materias)
        return materias

    def estudiantes_en_comun(self, id_a, id_b):
        a, b = self.obtener_por_id(id_a), self.obtener_por_id(id_b)
        if a is None or b is None:
            return None
        return set(a.materias) & set(b.materias)
