from views import EstudianteController

def mostrar(e):
    print(f"\nID: {e.id} | Nombre: {e.nombre} | Email: {e.email} | Carnet: {e.carnet}")
    print("Materias:", ", ".join(e.materias) if e.materias else "Ninguna")
    print("Notas:", e.notas if e.notas else "Ninguna")

def materias():
    texto = input("Materias separadas por coma: ").strip()
    return [x.strip() for x in texto.split(",") if x.strip()]

def main():
    c = EstudianteController()

    while True:
        print("""
========== SISTEMA DE ESTUDIANTES ==========
1. Agregar estudiante
2. Ver todos
3. Buscar estudiante
4. Actualizar estudiante
5. Eliminar estudiante
6. Agregar nota
7. Ver promedio
8. Materias ofertadas
9. Materias en común
0. Salir
=============================================
""")
        op = input("Opción: ").strip()

        if op == "1":
            n = input("Nombre: ")
            em = input("Email: ")
            ca = input("Carnet: ")
            ok, msg = c.crear_estudiante(n, em, ca, materias())
            print(msg)

        elif op == "2":
            for e in c.obtener_todos(): mostrar(e)

        elif op == "3":
            for e in c.buscar_estudiantes(input("Buscar: ")): mostrar(e)

        elif op == "4":
            try: i = int(input("ID: "))
            except ValueError:
                print("ID inválido."); continue
            e = c.obtener_por_id(i)
            if not e:
                print("No existe."); continue
            n = input(f"Nombre [{e.nombre}]: ") or e.nombre
            em = input(f"Email [{e.email}]: ") or e.email
            ca = input(f"Carnet [{e.carnet}]: ") or e.carnet
            print(c.actualizar_estudiante(i, n, em, ca)[1])

        elif op == "5":
            try: i = int(input("ID: "))
            except ValueError:
                print("ID inválido."); continue
            print(c.eliminar_estudiante(i)[1])

        elif op == "6":
            try: i = int(input("ID: "))
            except ValueError:
                print("ID inválido."); continue
            m = input("Materia: ")
            nota = input("Nota (0-20): ")
            print(c.agregar_nota(i, m, nota)[1])

        elif op == "7":
            try: i = int(input("ID: "))
            except ValueError:
                print("ID inválido."); continue
            p = c.promedio_estudiante(i)
            print("Promedio:", f"{p:.2f}" if p is not None else "Sin notas.")

        elif op == "8":
            print("Materias ofertadas:", ", ".join(sorted(c.materias_ofertadas())) or "Ninguna")

        elif op == "9":
            try:
                a = int(input("ID estudiante A: "))
                b = int(input("ID estudiante B: "))
            except ValueError:
                print("ID inválido."); continue
            r = c.estudiantes_en_comun(a, b)
            print("Materias en común:", ", ".join(sorted(r)) if r is not None and r else "Ninguna")

        elif op == "0":
            print("Programa finalizado.")
            break
        else:
            print("Opción no válida.")

if __name__ == "__main__":
    main()
