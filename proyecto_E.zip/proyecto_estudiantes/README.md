# Proyecto Estudiantes

Sistema en Python con arquitectura MVC sencilla.

## Archivos
- `models.py`: clase `Estudiante`.
- `views.py`: controlador y operaciones CRUD.
- `main.py`: menú e interacción con el usuario.
- `data/estudiantes.json`: almacenamiento de datos.

## Ejecutar
```bash
python main.py
```

## Incluye
CRUD de estudiantes, validación de email y carnet, agregar notas de 0 a 20,
promedio, materias ofertadas mediante `set` y materias en común mediante
intersección de conjuntos.
